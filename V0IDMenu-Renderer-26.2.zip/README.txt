V0IDMenu Java UI resource pack - renderer-engine milestone

Target: Minecraft Java 26.2 / resource pack format 88.0.

Scope:
- Repaints vanilla normal/highlighted/disabled button chrome.
- Repaints vanilla normal/highlighted text fields.
- Does NOT include the V0ID logo.
- Does NOT define custom UI icon glyphs.
- V0IDMenu uses vanilla Minecraft item sprites for menu icons.

Important:
These widget sprites are global vanilla UI assets. While this pack is active,
the same button/text-field chrome can appear in other vanilla screens too.
The V0ID renderer engine does not rely on this pack for behavior.
