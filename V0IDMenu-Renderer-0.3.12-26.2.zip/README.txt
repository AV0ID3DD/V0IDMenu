V0IDMenu Java UI resource pack - 0.3.12 info-panel milestone

Target: Minecraft Java 26.2 / resource pack format 88.0.

Scope:
- Repaints vanilla normal/highlighted/disabled button chrome.
- Repaints vanilla normal/highlighted text fields.
- Adds passive V0IDMenu info-panel bitmap-font glyphs under the v0idmenu:ui font.
- Info panels have no action, callback or selectable/focusable hitbox.
- Does NOT include the V0ID logo.
- Does NOT define custom menu/item icon glyphs. V0IDMenu still uses vanilla Minecraft item sprites for menu icons.

Important:
The vanilla widget sprites are global UI assets while this pack is active.
The v0idmenu:ui font is namespaced and is only used by V0IDMenu for passive panel backgrounds/spacing.
Without this updated pack, 0.3.12 info-panel glyphs will not render correctly.
